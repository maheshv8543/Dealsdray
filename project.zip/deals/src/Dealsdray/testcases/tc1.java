package Dealsdray.testcases;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import Dealsdray.genericlib.BaseClass;

public class tc1 extends BaseClass {
	@Test
	public void orders() throws IOException, AWTException
	{
		String dealsOrder=du.getDataFromProperties("value");
		driver.findElement(By.xpath("//span[text()='Order']")).click();
		driver.findElement(By.xpath("//span[text()='Orders']")).click();
		driver.findElement(By.xpath("//button[text()='Add Bulk Orders']")).click();
		driver.findElement(By.cssSelector("[type='file']")).sendKeys("C:\\Users\\mahes\\OneDrive\\Desktop\\deals\\demo-data (3).xlsx");
		driver.findElement(By.xpath("//button[text()='Import']")).click();
		driver.findElement(By.xpath("//button[text()='Validate Data']")).click();
		cu.validatekeys();
		cu.takeScreenshotOfEntirePage(driver);
		
		 
	}
	
	

}
