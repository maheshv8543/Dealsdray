package resolution;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import java.io.File;
import java.util.HashMap;
public class reso {


	
		public static final String URL = "https://YOUR_USERNAME:YOUR_ACCESS_KEY@hub-cloud.browserstack.com/wd/";
		public static void main(String[] args) throws Exception {
			 MutableCapabilities caps = new MutableCapabilities();
			 caps.setCapability("browserName", "chrome");
			 HashMap<String, Object> browserstackOptions = new HashMap<String, Object>();
			 browserstackOptions.put("os", "Windows");
			 browserstackOptions.put("osVersion", "11");
			
			 MutableCapabilities capabilities = new MutableCapabilities();
			 browserstackOptions.put("resolution", "1024x768");
			
			 browserstackOptions.put("seleniumVersion", "4.10.0");
			caps.setCapability("bstack:options", browserstackOptions);
			 WebDriver driver = new ChromeDriver();
			 driver.get("https://www.getcalley.com/page-sitemap.xml");
			 
			// driver.manage().window().maximize();
			 //driver.quit();
			 TakesScreenshot ts=(TakesScreenshot)driver;
			 File src=ts.getScreenshotAs(OutputType.FILE);
			 File trg=new File("./resolution/7:31&6_19_2330.png");
			 FileUtils.copyFile(src, trg);
			 driver.close();
		}
	}



