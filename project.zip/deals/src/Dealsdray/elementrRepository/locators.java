package Dealsdray.elementrRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class locators {
	public locators(WebDriver driver)  {
		PageFactory.initElements(driver,this);
	}
	@FindBy(name="username")
	private WebElement Username;
	@FindBy(name="password")
	private WebElement pwd;
	@FindBy(css="[type='submit']")
	private WebElement submit;
	
	
	public WebElement getUsername()
	{
		return Username;
		
	}
	public WebElement getpwd()
	{
		return pwd;
		
	}
	public WebElement getsubmit()
	{
		return submit;
		
	}
	public void loginApp(String Username,String pwd)
	{
		getUsername().sendKeys(Username);
		getpwd().sendKeys(pwd);
		getsubmit().click();
	}



	
	
	
	
}
